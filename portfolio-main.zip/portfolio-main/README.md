# portfolio
Required:
Software/Hardware
Laptop/Compouiter/v.s.code/html/css/Bootstrap
